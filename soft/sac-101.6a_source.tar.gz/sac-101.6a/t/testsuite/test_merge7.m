
read 2007.333.*TPNV*SAC
merge
lh b e npts kzdate kztime depmin depmax

