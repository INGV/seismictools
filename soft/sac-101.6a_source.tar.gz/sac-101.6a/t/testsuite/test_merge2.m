
merge test_merge6.sac test_merge4.sac test_merge1.sac test_merge3.sac test_merge2.sac test_merge5.sac test_merge6.sac
lh b e npts kzdate kztime


