* Some early comments
$keys keya keyb keyc
$default keya "key a value"
$default keyb "key b value"
                             
* comment
* another comment
* default keys after comments

$default keyc "key c value"

message $keya
message $keyb
message $keyc
