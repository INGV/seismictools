   * Example FAP File
* FAP (Frequency Amplitude Phase) Input for transfer
   * Frequency: Hz
   * Amplitude: nanometers
   * Phase:     radians
   * Interpolation is log-log in amplitude, linear in phase
1e-5 1.0 0.0
1.0 1.0 0.0
1e3 1.0 0.0


