$KEYS FILES VALUES
echo on
read $FILES
bp co $VALUES p 2 n 4
lh depmin depmax
