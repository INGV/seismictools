
message %empty
message hi
