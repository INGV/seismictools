
message "$empty"
message hi
