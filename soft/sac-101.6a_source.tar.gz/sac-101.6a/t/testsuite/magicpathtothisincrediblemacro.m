*
* magicpathtothisincrediblemacro
*
$keys hi lo file basef

message "Magic Macro"
message
message "$file $basef $lo $hi"
message "Magic Macro Done"
message