
merge test_merge6.sac test_merge4.sac test_merge1.sac test_merge3.sac test_merge5.sac test_merge6.sac test_merge2s.sac
lh b e kzdate kztime
