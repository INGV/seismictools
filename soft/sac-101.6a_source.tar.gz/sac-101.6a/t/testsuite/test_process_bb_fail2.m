
message "%empty"
message hi
