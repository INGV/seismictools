do  i = 1 , b
enddo
