
merge  test_merge6.sac test_merge5.sac test_merge6.sac
lh b e kztime kzdate
