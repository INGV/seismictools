* Early comments
     
$default 1 a
$default 2 b
$default 3 c

                             
* comment
* another comment

* redeclaration of 3rd parameter
$default 3 efff

message $1
message $2
message $3
