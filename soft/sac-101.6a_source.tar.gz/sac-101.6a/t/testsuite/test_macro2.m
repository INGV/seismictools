$KEYS files values

message "< files:  $files >"
message "< values: $values >"
