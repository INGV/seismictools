                             
* comment
* another comment
* keys not defined, but used


message $a
message $b
message $c

message "hey $d hello"
