do  i = 1 ,
enddo
