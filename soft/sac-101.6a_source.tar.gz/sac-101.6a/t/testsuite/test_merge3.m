
merge test_merge2s.sac test_merge1.sac
lh b e kzdate kztime
