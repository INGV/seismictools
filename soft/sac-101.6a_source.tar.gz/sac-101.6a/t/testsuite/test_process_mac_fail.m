
message $empty
message hi
