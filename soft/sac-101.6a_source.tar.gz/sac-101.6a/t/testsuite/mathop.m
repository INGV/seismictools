
mathop normal
message ((1+2)+3)  (1+(2+3))  (1+2+3)
mathop old
message ((1+2)+3)  (1+(2+3))  (1+2+3)

mathop normal
message ((1+2)-3)  (1+(2-3))  (1+2-3)
mathop old
message ((1+2)-3)  (1+(2-3))  (1+2-3)


mathop normal
message ((1+2)*3)  (1+(2*3))  (1+2*3)
mathop old
message ((1+2)*3)  (1+(2*3))  (1+2*3)

mathop normal
message ((1+2)/3)  (1+(2/3))  (1+2/3)
mathop old
message ((1+2)/3)  (1+(2/3))  (1+2/3)

mathop normal
message ((1+2)**3) (1+(2**3)) (1+2**3)
mathop old
message ((1+2)**3) (1+(2**3)) (1+2**3)

mathop normal
message ((1-2)+3)  (1-(2+3))  (1-2+3)
mathop old
message ((1-2)+3)  (1-(2+3))  (1-2+3)

mathop normal
message ((1-2)-3)  (1-(2-3))  (1-2-3)
mathop old
message ((1-2)-3)  (1-(2-3))  (1-2-3)

mathop normal
message ((1-2)*3)  (1-(2*3))  (1-2*3)
mathop old
message ((1-2)*3)  (1-(2*3))  (1-2*3)

mathop normal
message ((1-2)/3)  (1-(2/3))  (1-2/3)
mathop old
message ((1-2)/3)  (1-(2/3))  (1-2/3)

mathop normal
message ((1-2)**3) (1-(2**3)) (1-2**3)
mathop old
message ((1-2)**3) (1-(2**3)) (1-2**3)

mathop normal
message ((2*2)+3)  (2*(2+3))  (2*2+3)
mathop old
message ((2*2)+3)  (2*(2+3))  (2*2+3)

mathop normal
message ((2*2)-3)  (2*(2-3))  (2*2-3)
mathop old
message ((2*2)-3)  (2*(2-3))  (2*2-3)

mathop normal
message ((1*2)*3)  (1*(2*3))  (1*2*3)
mathop old
message ((1*2)*3)  (1*(2*3))  (1*2*3)

mathop normal
message ((1*2)/3)  (1*(2/3))   (1*2/3)
mathop old
message ((1*2)/3)  (1*(2/3))   (1*2/3)

mathop normal
message ((2*2)**3) (2*(2**3)) (2*2**3)
mathop old
message ((2*2)**3) (2*(2**3)) (2*2**3)

mathop normal
message ((1/2)+3) (1/(2+3)) (1/2+3)
mathop old
message ((1/2)+3) (1/(2+3)) (1/2+3)

mathop normal
message ((1/2)-3) (1/(2-3)) (1/2-3)
mathop old
message ((1/2)-3) (1/(2-3)) (1/2-3)

mathop normal
message ((1/2)*3) (1/(2*3)) (1/2*3)
mathop old
message ((1/2)*3) (1/(2*3)) (1/2*3)

mathop normal
message ((1/2)/3) (1/(2/3)) (1/2/3)
mathop old
message ((1/2)/3) (1/(2/3)) (1/2/3)

mathop normal
message ((3/2)**3) (3/(2**3)) (3/2**3)
mathop old
message ((3/2)**3) (3/(2**3)) (3/2**3)


mathop normal
message ((2**2)+3) (2**(2+3)) (2**2+3)
mathop old
message ((2**2)+3) (2**(2+3)) (2**2+3)

mathop normal
message ((2**2)-3) (2**(2-3)) (2**2-3)
mathop old
message ((2**2)-3) (2**(2-3)) (2**2-3)

mathop normal
message ((2**2)*3) (2**(2*3)) (2**2*3)
mathop old
message ((2**2)*3) (2**(2*3)) (2**2*3)

mathop normal
message ((2**2)/3) (2**(2/3)) (2**2/3)
mathop old
message ((2**2)/3) (2**(2/3)) (2**2/3)

mathop normal
message ((2**2)**3) (2**(2**3)) (2**2**3)
mathop old
message ((2**2)**3) (2**(2**3)) (2**2**3)

