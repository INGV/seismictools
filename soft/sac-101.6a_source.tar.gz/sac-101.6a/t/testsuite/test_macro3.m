$KEYS files values
$DEFAULT values 4 5 6
$DEFAULT files four five six

message "< files: $files >"
message "< values: $values >"