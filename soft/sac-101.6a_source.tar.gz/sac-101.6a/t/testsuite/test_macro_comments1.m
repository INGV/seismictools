     
message "Not a comment"
* message "Comment Here"
* message "Hi there, comment"
* message "Comment"
message "Not a comment"

* Comment


